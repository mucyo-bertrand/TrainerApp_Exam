const express= require("express");
const app= express();
const students=[];
class Student {
    constructor(name, grade) {
        this.grade = grade;
        this.name = name;
    }
    
    getDetails() {
        return `Name: ${this.name}, Grade: ${this.grade}`;
    }
}

app.use(express.json());
app.post("/students",(req,res)=>{
    const {name, grade}= req.body;
    const student= new Student(name,grade);
    students.push(student);
    console.log(students);
    res.status(200).send("Student added successfully");
});
app.get("/students", (req, res) => {
    const studentDetails = students.map(student => student.getDetails());
    res.status(200).json(studentDetails);
});

app.listen(4000,()=>console.log("Server running on http://localhost:4000"));